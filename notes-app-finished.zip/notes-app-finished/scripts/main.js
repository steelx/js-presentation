var $notes = $('#notes');
var $addForm = $('.add-note form');
var notesContainer = $notes.find('.container');
var addBtn = $addForm.find('button[type="submit"]');

var notes = [];

init();

function appendSingleNote(elem) {
  var buttons = '<a href="#" class="remove">X</a>';
  var title = '<p class="note-title">' + elem.title + '</p>';
  var content = '<p class="note-content">' + elem.content + '</p>';

  var note = 
          '<div class="note">' +
              buttons +
              title +
              content +
          '</div>';

  notesContainer.append(note);
}

function init() {
  if(!!window.localStorage.getItem('notes')) {
    notes = JSON.parse(window.localStorage.getItem('notes'));
  } else {
    notes = [];
  }

  var i = 0;
  for(i = 0; i < notes.length; i++) {
    appendSingleNote(notes[i]);
  }
}


function addNote() {
  var title = $addForm.find('.note-title'),
      content = $addForm.find('.note-content');

  //input validation
  if(title.val() === '' || content.val() === ''){
    alert('input cannot be empty');
    return;
  }
  
  //push into the array
  var notesObj = {title: title.val(), content: content.val()};
  notes.push(notesObj);
  window.localStorage.setItem('notes', JSON.stringify(notes));
  
  //update dom
  appendSingleNote(notesObj);
  
  //reset input
  title.val('');
  content.val('');
}


$addForm.on('submit', function(e){
  e.preventDefault();
  // console.log($(this).serializeArray());
  addNote();
});











